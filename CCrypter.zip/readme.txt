usage : ./ccrypter.py [OPTIONS]

-e : encryption without txt file
-d : decryption without txt file
-fe : encryption with txt file
-fd : decryprion with txt file

fb : www.facebook.com/hendri.glanex
github : www.github.com/mrSilent0598